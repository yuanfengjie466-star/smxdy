@echo off
chcp 65001 >nul
title SenseNova Chat 本地启动器

echo ==========================================
echo   SenseNova Chat 本地启动器
echo   开源 · 三模型混合调度 · 本地隐私保护
echo ==========================================
echo.

:: 检查 Node.js
echo [1/4] 检查环境...
node -v >nul 2>&1
if errorlevel 1 (
    echo 错误：未检测到 Node.js，请先安装 Node.js 20+
    echo 下载地址：https://nodejs.org/
    pause
    exit /b 1
)
for /f "tokens=1" %%a in ('node -v') do set NODE_V=%%a
echo       Node.js 版本: %NODE_V%
for /f "tokens=1" %%a in ('npm -v') do set NPM_V=%%a
echo       npm 版本: %NPM_V%
echo.

:: 检查依赖
echo [2/4] 检查依赖...
if not exist "node_modules" (
    echo       正在安装依赖（首次启动需要几分钟）...
    call npm install
    if errorlevel 1 (
        echo 错误：依赖安装失败
        pause
        exit /b 1
    )
) else (
    echo       依赖已安装
)
echo.

:: 构建项目
echo [3/4] 构建项目...
call npm run build >nul 2>&1
if errorlevel 1 (
    echo 警告：构建失败，尝试直接启动开发模式...
    echo.
    echo [4/4] 启动开发服务器...
    echo       浏览器将自动打开 http://localhost:3000
    echo       按 Ctrl+C 停止服务器
    echo.
    call npm run dev
) else (
    echo       构建成功
    echo.
    echo [4/4] 启动服务器...
    echo       浏览器将自动打开 http://localhost:3000
    echo       按 Ctrl+C 停止服务器
    echo.
    start http://localhost:3000
    call npm start
)

pause
